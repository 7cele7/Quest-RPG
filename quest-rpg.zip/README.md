# ✝️ BibleQuest RPG

**BibleQuest RPG** est une application mobile Android sous forme de jeu de rôle ludique et pédagogique pour explorer la Bible à travers des aventures, des énigmes, des boss et des reliques.

![Android](https://img.shields.io/badge/Android-7.0%2B-green.svg)
![Kotlin](https://img.shields.io/badge/Kotlin-Jetpack%20Compose-blue.svg)
![Build Status](https://github.com/USER/REPO/actions/workflows/android.yml/badge.svg)

---

## 📖 Fonctionnalités Principales

- **📱 Écran de Démarrage (Splash Screen)** : Design thématique sombre `#0F0D0A` avec reflets dorés `#C9A84C` et animation de pulsation lumineuse.
- **🏰 Hub Principal (Menu RPG)** :
  - Carte aventurier dynamique avec progression d'XP et niveaux.
  - Boutons de quête rapide : *Continuer*, *Nouvelle Aventure*, *Carte du Monde*, *Collection*, *Défis Quotidiens*, *Boutique*, *Paramètres*.
- **🗺️ Carte du Monde (66 Livres)** :
  - Vue d'ensemble de tous les 66 livres bibliques (39 Ancien Testament, 27 Nouveau Testament).
  - Statuts interactifs : Livres débloqués (Genèse, Exode) avec % de progression, et livres verrouillés 🔒.
- **📖 Quêtes & Énigmes (Genèse & Exode)** :
  - **Genèse** : 3 modes de difficulté (*Facile*, *Intermédiaire*, *Expert*) avec 13 étapes.
  - **Exode** : 2 modes de difficulté (*Facile*, *Intermédiaire*) avec 13 étapes.
  - Système de réponses interactives, aides avec indices et versets associés.
- **📚 Collection & Statistiques** :
  - Suivi des reliques débloquées et historiques de progression hors ligne.

---

## 🛠️ Architecture Technique

- **Langage** : Kotlin
- **UI Framework** : Jetpack Compose (Material Design 3)
- **Persistance Local** : SharedPreferences / JSON local dans `app/src/main/assets/`
- **Exécution Hors Ligne** : Aucune connexion Internet requise pour jouer.

---

## 🚀 Guide d'Installation Rapide

### Option A : Exporter directement depuis Google AI Studio (Recommandé)
1. Cliquez sur le menu de configuration/exportation en haut à droite dans Google AI Studio.
2. Choisissez **"Push to GitHub"** pour lier votre dépôt GitHub directement, ou **"Export ZIP"** pour télécharger tout le code sur votre ordinateur.

### Option B : Initialisation manuelle Git & Push vers GitHub
Ouvrez votre terminal dans le dossier du projet et exécutez :

```bash
# 1. Initialiser le dépôt Git
git init

# 2. Ajouter tous les fichiers
git add .

# 3. Créer le premier commit
git commit -m "feat: Version initiale BibleQuest RPG avec CI/CD GitHub Actions"

# 4. Renommer la branche principale en main
git branch -M main

# 5. Ajouter l'adresse de votre dépôt GitHub (remplacez l'URL par la vôtre)
git remote add origin https://github.com/VOTRE_PSEUDO/BibleQuest-RPG.git

# 6. Pousser le code vers GitHub
git push -u origin main
```

---

## ⚙️ Compilation & Génération de l'APK

### Avec GitHub Actions (Automatique)
Chaque fois que vous poussez (`git push`) du code sur la branche `main` :
1. Allez sur l'onglet **Actions** de votre dépôt GitHub.
2. Cliquez sur le dernier workflow exécuté : **Android CI - Build BibleQuest RPG APK**.
3. Dans la section **Artifacts**, téléchargez le fichier `BibleQuest-RPG-Debug-APK.zip`.
4. Extrayez le fichier `.apk` et installez-le sur votre téléphone Android.

### En local avec Gradle
```bash
# Compiler et générer l'APK Debug
gradle assembleDebug
```
L'APK sera disponible dans : `app/build/outputs/apk/debug/app-debug.apk`.

---

## 📄 Licence
Ce projet est développé pour la communauté d'apprentissage biblique et ludique.

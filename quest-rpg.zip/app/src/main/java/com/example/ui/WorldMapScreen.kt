package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

data class BibleBookItem(
    val id: String,
    val name: String,
    val emoji: String,
    val testament: String, // "Ancien" or "Nouveau"
    val isUnlocked: Boolean,
    val progressPercent: Int,
    val etapesCount: Int = 13
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorldMapScreen(
    geneseUnlockedEtape: Int,
    exodeUnlockedEtape: Int,
    onSelectGenese: () -> Unit,
    onSelectExode: () -> Unit,
    onBack: () -> Unit
) {
    var selectedTestamentFilter by remember { mutableStateOf("ALL") } // ALL, ANCIEN, NOUVEAU

    val geneseProgress = (((geneseUnlockedEtape - 1).coerceIn(0, 13).toFloat() / 13f) * 100).toInt()
    val exodeProgress = (((exodeUnlockedEtape - 1).coerceIn(0, 13).toFloat() / 13f) * 100).toInt()

    val allBibleBooks = remember(geneseProgress, exodeProgress) {
        listOf(
            // Ancien Testament
            BibleBookItem("genese", "Genèse", "📖", "Ancien", true, geneseProgress),
            BibleBookItem("exode", "Exode", "🌊", "Ancien", true, exodeProgress),
            BibleBookItem("levitique", "Lévitique", "📜", "Ancien", false, 0),
            BibleBookItem("nombres", "Nombres", "🔢", "Ancien", false, 0),
            BibleBookItem("deuteronome", "Deutéronome", "📜", "Ancien", false, 0),
            BibleBookItem("josue", "Josué", "⚔️", "Ancien", false, 0),
            BibleBookItem("juges", "Juges", "⚖️", "Ancien", false, 0),
            BibleBookItem("ruth", "Ruth", "🌾", "Ancien", false, 0),
            BibleBookItem("1samuel", "1 Samuel", "👑", "Ancien", false, 0),
            BibleBookItem("2samuel", "2 Samuel", "🏰", "Ancien", false, 0),
            BibleBookItem("1rois", "1 Rois", "🏛️", "Ancien", false, 0),
            BibleBookItem("2rois", "2 Rois", "👑", "Ancien", false, 0),
            BibleBookItem("1chroniques", "1 Chroniques", "📜", "Ancien", false, 0),
            BibleBookItem("2chroniques", "2 Chroniques", "🏰", "Ancien", false, 0),
            BibleBookItem("esdras", "Esdras", "🏗️", "Ancien", false, 0),
            BibleBookItem("nehemie", "Néhémie", "🧱", "Ancien", false, 0),
            BibleBookItem("esther", "Esther", "👑", "Ancien", false, 0),
            BibleBookItem("job", "Job", "🌧️", "Ancien", false, 0),
            BibleBookItem("pseaumes", "Psaumes", "🎵", "Ancien", false, 0),
            BibleBookItem("proverbes", "Proverbes", "💡", "Ancien", false, 0),
            BibleBookItem("ecclesiaste", "Ecclésiaste", "⏳", "Ancien", false, 0),
            BibleBookItem("cantique", "Cantique des C.", "🌹", "Ancien", false, 0),
            BibleBookItem("esaie", "Ésaïe", "🦅", "Ancien", false, 0),
            BibleBookItem("jeremie", "Jérémie", "🏺", "Ancien", false, 0),
            BibleBookItem("lamentations", "Lamentations", "💧", "Ancien", false, 0),
            BibleBookItem("ezechiel", "Ézéchiel", "🔥", "Ancien", false, 0),
            BibleBookItem("daniel", "Daniel", "🦁", "Ancien", false, 0),
            BibleBookItem("osee", "Osée", "💍", "Ancien", false, 0),
            BibleBookItem("joel", "Joël", "🌾", "Ancien", false, 0),
            BibleBookItem("amos", "Amos", "⚖️", "Ancien", false, 0),
            BibleBookItem("abdias", "Abdias", "🏔️", "Ancien", false, 0),
            BibleBookItem("jonas", "Jonas", "🐋", "Ancien", false, 0),
            BibleBookItem("michee", "Michée", "🕊️", "Ancien", false, 0),
            BibleBookItem("nahum", "Nahum", "🛡️", "Ancien", false, 0),
            BibleBookItem("habacuc", "Habacuc", "🔭", "Ancien", false, 0),
            BibleBookItem("sophonie", "Sophonie", "🌅", "Ancien", false, 0),
            BibleBookItem("aggee", "Aggée", "🏛️", "Ancien", false, 0),
            BibleBookItem("zacharie", "Zacharie", "🌟", "Ancien", false, 0),
            BibleBookItem("malachie", "Malachie", "☀️", "Ancien", false, 0),

            // Nouveau Testament
            BibleBookItem("matthieu", "Matthieu", "✝️", "Nouveau", false, 0),
            BibleBookItem("marc", "Marc", "🦁", "Nouveau", false, 0),
            BibleBookItem("luc", "Luc", "🕊️", "Nouveau", false, 0),
            BibleBookItem("jean", "Jean", "🦅", "Nouveau", false, 0),
            BibleBookItem("actes", "Actes", "🔥", "Nouveau", false, 0),
            BibleBookItem("romains", "Romains", "📜", "Nouveau", false, 0),
            BibleBookItem("1corinthiens", "1 Corinthiens", "✉️", "Nouveau", false, 0),
            BibleBookItem("2corinthiens", "2 Corinthiens", "✉️", "Nouveau", false, 0),
            BibleBookItem("galates", "Galates", "🕊️", "Nouveau", false, 0),
            BibleBookItem("ephesiens", "Éphésiens", "🛡️", "Nouveau", false, 0),
            BibleBookItem("philippiens", "Philippiens", "🌟", "Nouveau", false, 0),
            BibleBookItem("colossiens", "Colossiens", "👑", "Nouveau", false, 0),
            BibleBookItem("1thessaloniciens", "1 Thess.", "✉️", "Nouveau", false, 0),
            BibleBookItem("2thessaloniciens", "2 Thess.", "✉️", "Nouveau", false, 0),
            BibleBookItem("1timothee", "1 Timothée", "📜", "Nouveau", false, 0),
            BibleBookItem("2timothee", "2 Timothée", "📜", "Nouveau", false, 0),
            BibleBookItem("tite", "Tite", "⚓", "Nouveau", false, 0),
            BibleBookItem("philemon", "Philémon", "⛓️", "Nouveau", false, 0),
            BibleBookItem("hebreux", "Hébreux", "🏛️", "Nouveau", false, 0),
            BibleBookItem("jacques", "Jacques", "🌱", "Nouveau", false, 0),
            BibleBookItem("1pierre", "1 Pierre", "🪨", "Nouveau", false, 0),
            BibleBookItem("2pierre", "2 Pierre", "⚓", "Nouveau", false, 0),
            BibleBookItem("1jean", "1 Jean", "❤️", "Nouveau", false, 0),
            BibleBookItem("2jean", "2 Jean", "✉️", "Nouveau", false, 0),
            BibleBookItem("3jean", "3 Jean", "✉️", "Nouveau", false, 0),
            BibleBookItem("jude", "Jude", "🛡️", "Nouveau", false, 0),
            BibleBookItem("apocalypse", "Apocalypse", "👑", "Nouveau", false, 0)
        )
    }

    val filteredBooks = remember(selectedTestamentFilter, allBibleBooks) {
        when (selectedTestamentFilter) {
            "ANCIEN" -> allBibleBooks.filter { it.testament == "Ancien" }
            "NOUVEAU" -> allBibleBooks.filter { it.testament == "Nouveau" }
            else -> allBibleBooks
        }
    }

    Scaffold(
        containerColor = DarkBackground,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "🗺️ CARTE DU MONDE",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            color = GoldPrimary
                        )
                        Text(
                            text = "66 Livres de la Bible • Quêtes & Énigmes",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("btn_back_worldmap")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Retour",
                            tint = GoldPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            // Filter Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedTestamentFilter == "ALL",
                    onClick = { selectedTestamentFilter = "ALL" },
                    label = { Text("Tous (66)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldPrimary,
                        selectedLabelColor = DarkBackground,
                        containerColor = CardBackground,
                        labelColor = TextPrimary
                    )
                )
                FilterChip(
                    selected = selectedTestamentFilter == "ANCIEN",
                    onClick = { selectedTestamentFilter = "ANCIEN" },
                    label = { Text("Ancien T. (39)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldPrimary,
                        selectedLabelColor = DarkBackground,
                        containerColor = CardBackground,
                        labelColor = TextPrimary
                    )
                )
                FilterChip(
                    selected = selectedTestamentFilter == "NOUVEAU",
                    onClick = { selectedTestamentFilter = "NOUVEAU" },
                    label = { Text("Nouveau T. (27)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldPrimary,
                        selectedLabelColor = DarkBackground,
                        containerColor = CardBackground,
                        labelColor = TextPrimary
                    )
                )
            }

            // Status Summary Header
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBackground),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GoldPrimary, CardBorder))),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("2 / 66", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
                        Text("Débloqués", fontSize = 11.sp, color = TextSecondary)
                    }
                    Box(modifier = Modifier.width(1.dp).height(24.dp).background(CardBorder))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Genèse & Exode", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("Aventure Active", fontSize = 11.sp, color = GoldLight)
                    }
                    Box(modifier = Modifier.width(1.dp).height(24.dp).background(CardBorder))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("64", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                        Text("🔒 Verrouillés", fontSize = 11.sp, color = TextSecondary)
                    }
                }
            }

            // Grid of 66 Books
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredBooks, key = { it.id }) { book ->
                    WorldMapBookCard(
                        book = book,
                        onClick = {
                            if (book.id == "genese") {
                                onSelectGenese()
                            } else if (book.id == "exode") {
                                onSelectExode()
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun WorldMapBookCard(
    book: BibleBookItem,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (book.isUnlocked) CardBackground else CardBackground.copy(alpha = 0.4f)
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (book.isUnlocked) GoldPrimary else CardBorder.copy(alpha = 0.4f)
        ),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(115.dp)
            .clickable(enabled = book.isUnlocked) { onClick() }
            .testTag("book_card_${book.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Icon / Lock Indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = book.emoji,
                    fontSize = 20.sp,
                    modifier = Modifier.padding(start = 2.dp)
                )
                if (!book.isUnlocked) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Verrouillé",
                        tint = TextSecondary.copy(alpha = 0.5f),
                        modifier = Modifier.size(14.dp)
                    )
                } else {
                    Text(
                        text = "${book.progressPercent}%",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldLight
                    )
                }
            }

            // Title
            Text(
                text = book.name,
                fontSize = 12.sp,
                fontWeight = if (book.isUnlocked) FontWeight.Bold else FontWeight.Normal,
                color = if (book.isUnlocked) TextPrimary else TextSecondary.copy(alpha = 0.6f),
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            // Progress bar or locked status label
            if (book.isUnlocked) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    LinearProgressIndicator(
                        progress = { book.progressPercent / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = GoldPrimary,
                        trackColor = CardBorder
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "DISPONIBLE",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldPrimary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            } else {
                Text(
                    text = "🔒 Verrouillé",
                    fontSize = 9.sp,
                    color = TextSecondary.copy(alpha = 0.5f),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

package com.example.data

import android.content.Context
import android.content.SharedPreferences

data class StepSessionData(
    val levelKey: String,
    val etapeNumber: Int,
    val currentQuestionIndex: Int,
    val score: Int,
    val isStepCompleted: Boolean = false
)

data class LevelStats(
    val levelKey: String,
    val completedEtapes: Int,
    val totalEtapes: Int = 13,
    val totalCorrectAnswers: Int,
    val totalQuestionsAttempted: Int,
    val totalTimeSeconds: Long
) {
    val successRatePercentage: Int
        get() = if (totalQuestionsAttempted > 0) ((totalCorrectAnswers * 100) / totalQuestionsAttempted).coerceIn(0, 100) else 0

    val formattedTime: String
        get() {
            if (totalTimeSeconds <= 0) return "0s"
            val mins = totalTimeSeconds / 60
            val secs = totalTimeSeconds % 60
            return if (mins > 0) "${mins} min ${secs}s" else "${secs}s"
        }
}

data class GlobalBookStats(
    val bookName: String = "Genèse",
    val completedEtapes: Int,
    val totalEtapes: Int = 39,
    val totalCorrectAnswers: Int,
    val totalQuestionsAttempted: Int,
    val totalTimeSeconds: Long,
    val levelStatsList: List<LevelStats>
) {
    val successRatePercentage: Int
        get() = if (totalQuestionsAttempted > 0) ((totalCorrectAnswers * 100) / totalQuestionsAttempted).coerceIn(0, 100) else 0

    val formattedTime: String
        get() {
            if (totalTimeSeconds <= 0) return "0s"
            val hours = totalTimeSeconds / 3600
            val mins = (totalTimeSeconds % 3600) / 60
            val secs = totalTimeSeconds % 60
            return when {
                hours > 0 -> "${hours}h ${mins}m"
                mins > 0 -> "${mins} min ${secs}s"
                else -> "${secs}s"
            }
        }
}

object ProgressManager {
    private const val PREF_NAME = "bible_quest_progress"

    private fun getKey(levelKey: String): String {
        val normalized = levelKey.lowercase().trim()
        return "max_unlocked_etape_$normalized"
    }

    private fun getSessionKey(levelKey: String): String {
        val normalized = levelKey.lowercase().trim()
        return "active_session_$normalized"
    }

    fun getMaxUnlockedEtape(context: Context, levelKey: String = "facile"): Int {
        val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val key = getKey(levelKey)
        
        // Migrate legacy single preference key if exists
        if (!prefs.contains(key) && prefs.contains("max_unlocked_etape") && levelKey.equals("facile", ignoreCase = true)) {
            val oldVal = prefs.getInt("max_unlocked_etape", 1)
            prefs.edit().putInt(key, oldVal).apply()
        }

        return prefs.getInt(key, 1)
    }

    fun unlockNextEtape(context: Context, completedEtape: Int, levelKey: String = "facile"): Boolean {
        return try {
            val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val key = getKey(levelKey)
            val currentMax = prefs.getInt(key, 1)
            if (completedEtape + 1 > currentMax) {
                prefs.edit().putInt(key, completedEtape + 1).apply()
                android.util.Log.d("BibleQuestLogs", "✓ Progression débloquée avec succès: Étape ${completedEtape + 1} pour niveau $levelKey")
            }
            clearActiveSession(context, levelKey)
            true
        } catch (e: Exception) {
            android.util.Log.e("BibleQuestLogs", "❌ Erreur lors du déblocage de l'étape suivante: ${e.message}", e)
            false
        }
    }

    fun saveEtapeResult(
        context: Context,
        levelKey: String,
        etapeNum: Int,
        score: Int,
        totalQuestions: Int,
        timeSeconds: Int
    ): Boolean {
        return try {
            val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val norm = levelKey.lowercase().trim()
            val statKey = "etape_stat_${norm}_$etapeNum"
            val value = "$score:$totalQuestions:$timeSeconds"
            prefs.edit().putString(statKey, value).apply()
            android.util.Log.d("BibleQuestLogs", "✓ Résultat enregistré pour $norm Étape $etapeNum ($value)")
            true
        } catch (e: Exception) {
            android.util.Log.e("BibleQuestLogs", "❌ Échec de la sauvegarde des résultats de l'étape $etapeNum: ${e.message}", e)
            false
        }
    }

    fun getLevelStats(context: Context, levelKey: String): LevelStats {
        val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val norm = levelKey.lowercase().trim()
        val maxUnlocked = getMaxUnlockedEtape(context, norm)
        val totalEtapes = 13

        var completedCount = (maxUnlocked - 1).coerceIn(0, totalEtapes)
        if (maxUnlocked >= 13) {
            val bossStat = prefs.getString("etape_stat_${norm}_13", null)
            if (bossStat != null) {
                completedCount = 13
            }
        }

        var totalCorrect = 0
        var totalQuestions = 0
        var totalTime: Long = 0L

        for (e in 1..totalEtapes) {
            val statVal = prefs.getString("etape_stat_${norm}_$e", null)
            if (statVal != null) {
                val parts = statVal.split(":")
                if (parts.size >= 3) {
                    totalCorrect += parts[0].toIntOrNull() ?: 0
                    totalQuestions += parts[1].toIntOrNull() ?: 0
                    totalTime += parts[2].toLongOrNull() ?: 0L
                }
            } else if (e <= completedCount) {
                // Default baseline for steps completed prior to exact stat tracking
                totalCorrect += 8
                totalQuestions += 10
                totalTime += 60L
            }
        }

        return LevelStats(
            levelKey = norm,
            completedEtapes = completedCount,
            totalEtapes = totalEtapes,
            totalCorrectAnswers = totalCorrect,
            totalQuestionsAttempted = totalQuestions,
            totalTimeSeconds = totalTime
        )
    }

    fun getGlobalBookStats(context: Context): GlobalBookStats {
        val levels = listOf("facile", "intermediaire", "expert")
        val levelStatsList = levels.map { getLevelStats(context, it) }

        val totalCompleted = levelStatsList.sumOf { it.completedEtapes }
        val totalEtapes = levelStatsList.sumOf { it.totalEtapes }
        val totalCorrect = levelStatsList.sumOf { it.totalCorrectAnswers }
        val totalQ = levelStatsList.sumOf { it.totalQuestionsAttempted }
        val totalTime = levelStatsList.sumOf { it.totalTimeSeconds }

        return GlobalBookStats(
            bookName = "Genèse",
            completedEtapes = totalCompleted,
            totalEtapes = totalEtapes,
            totalCorrectAnswers = totalCorrect,
            totalQuestionsAttempted = totalQ,
            totalTimeSeconds = totalTime,
            levelStatsList = levelStatsList
        )
    }

    fun saveActiveSession(context: Context, session: StepSessionData): Boolean {
        return try {
            val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val key = getSessionKey(session.levelKey)
            if (session.isStepCompleted) {
                prefs.edit().remove(key).apply()
            } else {
                val value = "${session.etapeNumber}:${session.currentQuestionIndex}:${session.score}"
                prefs.edit().putString(key, value).apply()
            }
            android.util.Log.d("BibleQuestLogs", "✓ Session active enregistrée pour ${session.levelKey} Étape ${session.etapeNumber}")
            true
        } catch (e: Exception) {
            android.util.Log.e("BibleQuestLogs", "❌ Échec de l'enregistrement de la session active: ${e.message}", e)
            false
        }
    }

    fun getActiveSession(context: Context, levelKey: String): StepSessionData? {
        return try {
            val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val key = getSessionKey(levelKey)
            val value = prefs.getString(key, null) ?: return null
            val parts = value.split(":")
            if (parts.size >= 3) {
                val etapeNum = parts[0].toIntOrNull() ?: return null
                val qIndex = parts[1].toIntOrNull() ?: 0
                val score = parts[2].toIntOrNull() ?: 0
                StepSessionData(
                    levelKey = levelKey,
                    etapeNumber = etapeNum,
                    currentQuestionIndex = qIndex,
                    score = score,
                    isStepCompleted = false
                )
            } else null
        } catch (e: Exception) {
            android.util.Log.e("BibleQuestLogs", "❌ Échec de la récupération de la session active: ${e.message}", e)
            null
        }
    }

    fun clearActiveSession(context: Context, levelKey: String) {
        val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val key = getSessionKey(levelKey)
        prefs.edit().remove(key).apply()
    }

    fun resetLevelProgress(context: Context, levelKey: String) {
        val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val norm = levelKey.lowercase().trim()
        val unlockKey = getKey(norm)
        val sessionKey = getSessionKey(norm)
        val editor = prefs.edit()
            .putInt(unlockKey, 1)
            .remove(sessionKey)
        for (e in 1..13) {
            editor.remove("etape_stat_${norm}_$e")
        }
        editor.apply()
    }
}



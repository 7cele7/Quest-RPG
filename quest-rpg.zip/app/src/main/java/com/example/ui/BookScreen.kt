package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.EtapeData
import com.example.data.LivreData
import com.example.ui.theme.*

import androidx.compose.ui.platform.LocalContext
import com.example.data.ProgressManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookScreen(
    livreData: LivreData?,
    errorMessage: String? = null,
    maxUnlockedEtape: Int = 1,
    selectedLevelKey: String = "facile",
    onSelectLevel: (String) -> Unit = {},
    onResetLevel: () -> Unit = {},
    onBack: () -> Unit,
    onSelectEtapeToPlay: (EtapeData) -> Unit
) {
    val context = LocalContext.current
    var showResetDialog by remember { mutableStateOf(false) }

    val activeSession = remember(selectedLevelKey, maxUnlockedEtape) {
        ProgressManager.getActiveSession(context, selectedLevelKey)
    }

    val levelName = when (selectedLevelKey) {
        "facile" -> "Facile 🟢"
        "intermediaire" -> "Intermédiaire 🟡"
        "expert" -> "Expert 🔴"
        else -> selectedLevelKey.replaceFirstChar { it.uppercase() }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = {
                Text(
                    text = "Réinitialiser la progression ?",
                    fontWeight = FontWeight.Bold,
                    color = GoldPrimary
                )
            },
            text = {
                Text(
                    text = "Voulez-vous vraiment réinitialiser la progression du niveau $levelName ? Vous repartirez de l'étape 1 et la sauvegarde en cours sera effacée.",
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResetDialog = false
                        onResetLevel()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BossRed)
                ) {
                    Text("Réinitialiser", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("Annuler", color = TextSecondary)
                }
            },
            containerColor = CardBackground
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "📖 ${livreData?.livre ?: "Genèse"}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary
                        )
                        Text(
                            text = "${livreData?.etapes?.size ?: 13} Étapes • Niveau $levelName",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("btn_back_book")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Retour",
                            tint = GoldPrimary
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showResetDialog = true },
                        modifier = Modifier.testTag("btn_reset_level")
                    ) {
                        Text("🔄", fontSize = 18.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CardBackground
                )
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Level Selector Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val levels = listOf(
                    Triple("facile", "🟢 Facile", GoldPrimary),
                    Triple("intermediaire", "🟡 Intermédiaire", AccentBlue),
                    Triple("expert", "🔴 Expert", BossRed)
                )

                levels.forEach { (key, label, accentColor) ->
                    val isSelected = selectedLevelKey.equals(key, ignoreCase = true)
                    Surface(
                        color = if (isSelected) accentColor.copy(alpha = 0.2f) else CardBackground,
                        border = BorderStroke(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) accentColor else CardBorder
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSelectLevel(key) }
                            .testTag("level_tab_$key")
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.padding(vertical = 10.dp)
                        ) {
                            Text(
                                text = label,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) accentColor else TextSecondary
                            )
                        }
                    }
                }
            }

            if (livreData == null) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CardBackground),
                        border = BorderStroke(1.5.dp, if (errorMessage != null) BossRed else GoldPrimary.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth()
                            .testTag("card_book_load_error")
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(if (errorMessage != null) "❌" else "⏳", fontSize = 44.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (errorMessage != null) "Erreur de Chargement" else "Niveau Bientôt Disponible !",
                                color = if (errorMessage != null) BossRed else GoldPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = errorMessage ?: "Le niveau $levelName est prêt à être chargé. Dès que le fichier de données sera ajouté, les 13 étapes s'afficheront automatiquement !",
                                color = TextSecondary,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { onSelectLevel(selectedLevelKey) },
                                    colors = ButtonDefaults.buttonColors(containerColor = CardBorder)
                                ) {
                                    Text("Réessayer 🔄", color = TextPrimary, fontWeight = FontWeight.Bold)
                                }
                                if (!selectedLevelKey.equals("facile", ignoreCase = true)) {
                                    Button(
                                        onClick = { onSelectLevel("facile") },
                                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                                    ) {
                                        Text("Facile 🟢", color = DarkBackground, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        // Summary Banner
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CardBackground),
                            border = BorderStroke(1.dp, CardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("📜", fontSize = 28.sp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Livre 1 : Genèse ($levelName)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = GoldPrimary
                                    )
                                    Text(
                                        text = "Du Jardin d'Éden aux Rêves de Joseph • Progression indépendante",
                                        fontSize = 11.sp,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }

                    items(livreData.etapes) { etape ->
                        val isBoss = etape.type == "BOSS" || etape.etape == 13
                        val isUnlocked = etape.etape <= maxUnlockedEtape
                        val isCurrentSavedEtape = activeSession != null && activeSession.etapeNumber == etape.etape
                        val isNewlyUnlocked = isUnlocked && (etape.etape == maxUnlockedEtape) && (maxUnlockedEtape > 1) && !isCurrentSavedEtape

                        val infiniteTransition = rememberInfiniteTransition(label = "stepGlow_${etape.etape}")
                        val glowAlpha by if (isNewlyUnlocked) {
                            infiniteTransition.animateFloat(
                                initialValue = 0.4f,
                                targetValue = 1f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(700, easing = LinearEasing),
                                    repeatMode = RepeatMode.Reverse
                                ),
                                label = "glowAlpha"
                            )
                        } else {
                            remember { mutableStateOf(1f) }
                        }

                        val scalePulse by if (isNewlyUnlocked) {
                            infiniteTransition.animateFloat(
                                initialValue = 1f,
                                targetValue = 1.02f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(700, easing = FastOutSlowInEasing),
                                    repeatMode = RepeatMode.Reverse
                                ),
                                label = "scalePulse"
                            )
                        } else {
                            remember { mutableStateOf(1f) }
                        }

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = when {
                                    !isUnlocked -> CardBackground.copy(alpha = 0.5f)
                                    isCurrentSavedEtape -> CardBorder.copy(alpha = 0.4f)
                                    isBoss -> CardBackground.copy(alpha = 0.95f)
                                    isNewlyUnlocked -> CardBackground
                                    else -> CardBackground
                                }
                            ),
                            border = BorderStroke(
                                width = if ((isBoss || isCurrentSavedEtape || isNewlyUnlocked) && isUnlocked) 2.dp else 1.dp,
                                color = when {
                                    !isUnlocked -> CardBorder
                                    isCurrentSavedEtape -> GoldPrimary
                                    isBoss -> BossRed
                                    isNewlyUnlocked -> GoldLight.copy(alpha = glowAlpha)
                                    else -> CardBorder
                                }
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .scale(scalePulse)
                                .testTag("etape_card_${etape.etape}")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(
                                            color = when {
                                                !isUnlocked -> LockGray
                                                isBoss -> BossRed
                                                else -> GoldPrimary
                                            },
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = if (isBoss) "⚔️ BOSS" else "Étape ${etape.etape}",
                                                color = DarkBackground,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = etape.titre,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when {
                                                !isUnlocked -> TextSecondary
                                                isBoss -> BossRed
                                                else -> TextPrimary
                                            },
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    if (isNewlyUnlocked) {
                                        Surface(
                                            color = GoldPrimary.copy(alpha = 0.25f),
                                            shape = RoundedCornerShape(4.dp),
                                            border = BorderStroke(1.dp, GoldPrimary.copy(alpha = glowAlpha))
                                        ) {
                                            Text(
                                                text = "✨ DÉBLOQUÉ",
                                                color = GoldLight,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    } else if (isCurrentSavedEtape && activeSession != null) {
                                        Surface(
                                            color = GoldPrimary.copy(alpha = 0.2f),
                                            shape = RoundedCornerShape(4.dp),
                                            border = BorderStroke(1.dp, GoldPrimary)
                                        ) {
                                            Text(
                                                text = "💾 En cours Q${activeSession.currentQuestionIndex + 1}",
                                                color = GoldPrimary,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    } else if (!isUnlocked) {
                                        Surface(
                                            color = LockGray.copy(alpha = 0.2f),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = "🔒 Verrouillé",
                                                color = LockGray,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "📖 Chapitres : ${etape.chapitres}",
                                            fontSize = 11.sp,
                                            color = if (isUnlocked) GoldLight else TextSecondary
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = if (isUnlocked) "🏆 Récompense : ${etape.recompense.nom} (${etape.recompense.rarite})" else "🔒 Terminez l'étape ${etape.etape - 1} pour débloquer",
                                            fontSize = 11.sp,
                                            color = TextSecondary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    // Bouton "Jouer" / "Reprendre" / "Verrouillé"
                                    Button(
                                        onClick = { if (isUnlocked) onSelectEtapeToPlay(etape) },
                                        enabled = isUnlocked,
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isBoss) BossRed else GoldPrimary,
                                            disabledContainerColor = CardBorder
                                        ),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                                        modifier = Modifier.testTag("btn_play_etape_${etape.etape}")
                                    ) {
                                        if (isUnlocked) {
                                            Icon(
                                                imageVector = Icons.Default.PlayArrow,
                                                contentDescription = if (isCurrentSavedEtape) "Reprendre" else "Jouer",
                                                tint = DarkBackground,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (isCurrentSavedEtape) "Reprendre" else "Jouer",
                                                color = DarkBackground,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                        } else {
                                            Text(
                                                text = "🔒 Blocked",
                                                color = LockGray,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


package com.example.data

import android.content.Context
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

@JsonClass(generateAdapter = true)
data class LivreData(
    @Json(name = "livre") val livre: String = "Genèse",
    @Json(name = "ordre") val ordre: Int = 1,
    @Json(name = "total_etapes") val totalEtapes: Int = 13,
    @Json(name = "collection") val collection: List<ReliqueData> = emptyList(),
    @Json(name = "etapes") val etapes: List<EtapeData> = emptyList()
)

@JsonClass(generateAdapter = true)
data class ReliqueData(
    @Json(name = "id") val id: String = "",
    @Json(name = "nom") val nom: String = "",
    @Json(name = "type") val type: String = "",
    @Json(name = "rarite") val rarite: String = "",
    @Json(name = "categorie") val categorie: String = "",
    @Json(name = "description") val description: String = "",
    @Json(name = "verset") val verset: String = "",
    @Json(name = "etape") val etape: Int? = null,
    @Json(name = "image") val image: String? = null
)

@JsonClass(generateAdapter = true)
data class EtapeData(
    @Json(name = "etape") val etape: Int = 0,
    @Json(name = "titre") val titre: String = "",
    @Json(name = "chapitres") val chapitres: String = "",
    @Json(name = "niveau") val niveau: String = "facile",
    @Json(name = "type") val type: String? = null,
    @Json(name = "recompense") val recompense: ReliqueData = ReliqueData(),
    @Json(name = "questions") val questions: List<QuestionData> = emptyList()
)

@JsonClass(generateAdapter = true)
data class QuestionData(
    @Json(name = "id") val id: String = "",
    @Json(name = "type") val type: String = "choix_multiple",
    @Json(name = "chrono") val chrono: Boolean? = false,
    @Json(name = "time_limit") val timeLimit: Int? = null,
    @Json(name = "question") val question: String = "",
    @Json(name = "options") val options: List<String>? = null,
    @Json(name = "answer") val answer: String = "",
    @Json(name = "aliases") val aliases: List<String>? = null,
    @Json(name = "reference") val reference: String? = null
)

object JsonLoader {
    private const val TAG = "BibleQuestLogs"

    var lastErrorMessage: String? = null
        private set

    fun loadGeneseFacile(context: Context): LivreData? {
        return loadLivreLevel(context, "genese_facile.json")
    }

    fun loadLivreLevel(context: Context, assetFileName: String): LivreData? {
        android.util.Log.d(TAG, "=== DÉBUT DU CHARGEMENT DE $assetFileName ===")
        lastErrorMessage = null

        val jsonString = try {
            val inputStream = context.assets.open(assetFileName)
            val content = inputStream.bufferedReader().use { it.readText() }
            android.util.Log.d(TAG, "✓ Fichier asset '$assetFileName' trouvé et lu avec succès ! (Taille: ${content.length} caractères)")
            content
        } catch (e: Exception) {
            val err = "Fichier asset '$assetFileName' non disponible."
            android.util.Log.w(TAG, err)
            lastErrorMessage = err
            return null
        }

        if (jsonString.isBlank()) {
            val err = "❌ Le contenu du fichier $assetFileName est vide !"
            android.util.Log.e(TAG, err)
            lastErrorMessage = err
            return null
        }

        return try {
            val livreData = parseWithOrgJson(jsonString)
            android.util.Log.d(TAG, "✓ Parsing JSON réussi pour $assetFileName avec org.json !")
            android.util.Log.d(TAG, "   • Livre: ${livreData.livre}")
            android.util.Log.d(TAG, "   • Total étapes prévues: ${livreData.totalEtapes}")
            android.util.Log.d(TAG, "   • Nombre d'étapes chargées: ${livreData.etapes.size}")
            android.util.Log.d(TAG, "   • Nombre d'objets de collection chargés: ${livreData.collection.size}")
            
            livreData.etapes.forEach { etape ->
                android.util.Log.d(
                    TAG,
                    "   • [Étape ${etape.etape}] ${etape.titre} (${etape.questions.size} questions, chapitres: ${etape.chapitres})"
                )
            }

            android.util.Log.d(TAG, "=== CHARGEMENT TERMINÉ AVEC SUCCÈS POUR $assetFileName ===")
            livreData
        } catch (e: Exception) {
            val err = "❌ Erreur lors du parsing JSON de $assetFileName: ${e.message}"
            android.util.Log.e(TAG, err, e)
            lastErrorMessage = err
            null
        }
    }

    private fun parseWithOrgJson(jsonString: String): LivreData {
        val root = org.json.JSONObject(jsonString)
        val livre = root.optString("livre", "Genèse")
        val ordre = root.optInt("ordre", 1)
        val totalEtapes = root.optInt("total_etapes", 13)

        val collectionList = mutableListOf<ReliqueData>()
        val collectionArray = root.optJSONArray("collection")
        if (collectionArray != null) {
            for (i in 0 until collectionArray.length()) {
                val obj = collectionArray.getJSONObject(i)
                collectionList.add(
                    ReliqueData(
                        id = obj.optString("id", ""),
                        nom = obj.optString("nom", ""),
                        type = obj.optString("type", ""),
                        rarite = obj.optString("rarite", ""),
                        categorie = obj.optString("categorie", ""),
                        description = obj.optString("description", ""),
                        verset = obj.optString("verset", ""),
                        etape = if (obj.has("etape") && !obj.isNull("etape")) obj.optInt("etape") else null,
                        image = if (obj.has("image") && !obj.isNull("image")) obj.optString("image") else null
                    )
                )
            }
        }

        val etapesList = mutableListOf<EtapeData>()
        val etapesArray = root.optJSONArray("etapes")
        if (etapesArray != null) {
            for (i in 0 until etapesArray.length()) {
                val etapeObj = etapesArray.getJSONObject(i)

                var recompense = ReliqueData()
                val recObj = etapeObj.optJSONObject("recompense")
                if (recObj != null) {
                    recompense = ReliqueData(
                        id = recObj.optString("id", ""),
                        nom = recObj.optString("nom", ""),
                        type = recObj.optString("type", ""),
                        rarite = recObj.optString("rarite", ""),
                        categorie = recObj.optString("categorie", ""),
                        description = recObj.optString("description", ""),
                        verset = recObj.optString("verset", ""),
                        etape = if (recObj.has("etape") && !recObj.isNull("etape")) recObj.optInt("etape") else null,
                        image = if (recObj.has("image") && !recObj.isNull("image")) recObj.optString("image") else null
                    )
                }

                val questionsList = mutableListOf<QuestionData>()
                val questionsArray = etapeObj.optJSONArray("questions")
                val questionsObj = etapeObj.optJSONObject("questions")

                if (questionsArray != null) {
                    for (j in 0 until questionsArray.length()) {
                        questionsList.add(parseSingleQuestion(questionsArray.getJSONObject(j)))
                    }
                } else if (questionsObj != null) {
                    val targetObj = questionsObj.optJSONObject("expert")
                        ?: questionsObj.optJSONObject("facile")
                        ?: questionsObj.optJSONObject("intermediaire")
                        ?: questionsObj

                    val keys = targetObj.keys()
                    val phaseList = mutableListOf<Pair<Int, org.json.JSONObject>>()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        val phaseObj = targetObj.optJSONObject(key)
                        if (phaseObj != null) {
                            val phaseNum = phaseObj.optInt("phase", 99)
                            phaseList.add(Pair(phaseNum, phaseObj))
                        }
                    }
                    phaseList.sortBy { it.first }
                    for ((_, phaseObj) in phaseList) {
                        val poolArray = phaseObj.optJSONArray("pool")
                        if (poolArray != null) {
                            for (j in 0 until poolArray.length()) {
                                questionsList.add(parseSingleQuestion(poolArray.getJSONObject(j)))
                            }
                        }
                    }
                }

                etapesList.add(
                    EtapeData(
                        etape = etapeObj.optInt("etape", i + 1),
                        titre = etapeObj.optString("titre", ""),
                        chapitres = etapeObj.optString("chapitres", ""),
                        niveau = etapeObj.optString("niveau", "facile"),
                        type = if (etapeObj.has("type") && !etapeObj.isNull("type")) etapeObj.optString("type") else null,
                        recompense = recompense,
                        questions = questionsList
                    )
                )
            }
        }

        return LivreData(
            livre = livre,
            ordre = ordre,
            totalEtapes = totalEtapes,
            collection = collectionList,
            etapes = etapesList
        )
    }

    private fun parseSingleQuestion(qObj: org.json.JSONObject): QuestionData {
        val optionsList = mutableListOf<String>()
        val optsArray = qObj.optJSONArray("options")
        if (optsArray != null) {
            for (k in 0 until optsArray.length()) {
                optionsList.add(optsArray.getString(k))
            }
        }

        val aliasesList = mutableListOf<String>()
        val aliasesArray = qObj.optJSONArray("aliases")
        if (aliasesArray != null) {
            for (k in 0 until aliasesArray.length()) {
                aliasesList.add(aliasesArray.getString(k))
            }
        }

        return QuestionData(
            id = qObj.optString("id", ""),
            type = qObj.optString("type", "clavier"),
            chrono = if (qObj.has("chrono")) qObj.optBoolean("chrono", false) else false,
            timeLimit = if (qObj.has("time_limit") && !qObj.isNull("time_limit")) qObj.optInt("time_limit") else null,
            question = qObj.optString("question", ""),
            options = if (optionsList.isNotEmpty()) optionsList else null,
            answer = qObj.optString("answer", ""),
            aliases = if (aliasesList.isNotEmpty()) aliasesList else null,
            reference = if (qObj.has("reference") && !qObj.isNull("reference")) qObj.optString("reference") else null
        )
    }
}

package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun MainHubScreen(
    maxUnlockedEtapeGenese: Int = 1,
    maxUnlockedEtapeExode: Int = 1,
    onOpenGenese: () -> Unit,
    onOpenExode: () -> Unit,
    onOpenBoss: () -> Unit,
    onOpenCollection: () -> Unit,
    onOpenStats: () -> Unit,
    onShowToast: (String) -> Unit,
    onOpenWorldMap: () -> Unit = {}
) {
    var selectedBottomTab by remember { mutableIntStateOf(0) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showLeaderboardDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Scaffold(
        containerColor = DarkBackground,
        bottomBar = {
            NavigationBar(
                containerColor = CardBackground,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = selectedBottomTab == 0,
                    onClick = { selectedBottomTab = 0 },
                    icon = { Icon(Icons.Default.Menu, contentDescription = "Menu") },
                    label = { Text("Menu", color = if (selectedBottomTab == 0) GoldPrimary else TextSecondary) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GoldPrimary,
                        indicatorColor = CardBorder
                    ),
                    modifier = Modifier.testTag("nav_menu")
                )
                NavigationBarItem(
                    selected = selectedBottomTab == 1,
                    onClick = {
                        selectedBottomTab = 1
                        onOpenStats()
                    },
                    icon = { Icon(Icons.Default.BarChart, contentDescription = "Stats") },
                    label = { Text("Stats", color = if (selectedBottomTab == 1) GoldPrimary else TextSecondary) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GoldPrimary,
                        indicatorColor = CardBorder
                    ),
                    modifier = Modifier.testTag("nav_stats")
                )
                NavigationBarItem(
                    selected = selectedBottomTab == 2,
                    onClick = {
                        selectedBottomTab = 2
                        showProfileDialog = true
                    },
                    icon = { Icon(Icons.Default.Person, contentDescription = "Profil") },
                    label = { Text("Profil", color = if (selectedBottomTab == 2) GoldPrimary else TextSecondary) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GoldPrimary,
                        indicatorColor = CardBorder
                    ),
                    modifier = Modifier.testTag("nav_profile")
                )
                NavigationBarItem(
                    selected = selectedBottomTab == 3,
                    onClick = {
                        selectedBottomTab = 3
                        showLeaderboardDialog = true
                    },
                    icon = { Icon(Icons.Default.EmojiEvents, contentDescription = "Classement") },
                    label = { Text("Classement", color = if (selectedBottomTab == 3) GoldPrimary else TextSecondary) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GoldPrimary,
                        indicatorColor = CardBorder
                    ),
                    modifier = Modifier.testTag("nav_leaderboard")
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. En-tête (BibleQuest + Sous-titre)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Spacer(modifier = Modifier.width(36.dp))
                    Text(
                        text = "BibleQuest",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Serif,
                        color = GoldPrimary,
                        letterSpacing = 1.2.sp
                    )
                    IconButton(
                        onClick = { showSettingsDialog = true },
                        modifier = Modifier.testTag("btn_header_settings")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Paramètres",
                            tint = GoldPrimary
                        )
                    }
                }
                Text(
                    text = "RPG • AVENTURE • ÉNIGMES • BOSS • RELIQUES",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                HorizontalDivider(color = CardBorder, thickness = 1.dp)
            }

            // 2. Carte "Aventurier" (Niveau, XP, Titre)
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBackground),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GoldPrimary, CardBorder))),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenStats() }
                    .testTag("card_adventurer_profile")
            ) {
                Column(
                    modifier = Modifier.padding(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(CardBorder)
                                .border(1.dp, GoldPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("🧙‍♂️", fontSize = 26.sp)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "AVENTURIER",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldPrimary
                                )
                                Surface(
                                    color = GoldPrimary.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(8.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
                                ) {
                                    Text(
                                        text = "Niveau 1",
                                        color = GoldPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Titre : Disciple de la Parole",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val geneseDone = (maxUnlockedEtapeGenese - 1).coerceIn(0, 13)
                    val exodeDone = (maxUnlockedEtapeExode - 1).coerceIn(0, 13)
                    val currentXP = (geneseDone + exodeDone) * 50
                    val maxXP = 1300

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Expérience (XP)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary
                        )
                        Text(
                            text = "$currentXP / $maxXP XP",
                            fontSize = 11.sp,
                            color = GoldLight,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    val totalProgress = ((geneseDone + exodeDone).toFloat() / 26f).coerceIn(0f, 1f)
                    LinearProgressIndicator(
                        progress = { totalProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = GoldPrimary,
                        trackColor = CardBorder,
                    )
                }
            }

            // 3. Menu de Quête & Boutons Principaux
            Text(
                text = "📜 MENU DE L'AVENTURE",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = GoldPrimary,
                letterSpacing = 1.sp
            )

            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // CONTINUER
                RpgMenuButton(
                    title = "CONTINUER",
                    subtitle = "Reprendre votre quête en cours",
                    icon = "▶️",
                    goldBorder = true,
                    onClick = { onOpenGenese() },
                    tag = "btn_continuer"
                )

                // NOUVELLE AVENTURE
                RpgMenuButton(
                    title = "NOUVELLE AVENTURE",
                    subtitle = "Commencer la Genèse depuis le début",
                    icon = "⚔️",
                    goldBorder = false,
                    onClick = { onOpenGenese() },
                    tag = "btn_nouvelle_aventure"
                )

                // CARTE DU MONDE (Livres & Étapes)
                RpgMenuButton(
                    title = "CARTE DU MONDE",
                    subtitle = "Explorez Genèse, Exode & Boss",
                    icon = "🗺️",
                    goldBorder = false,
                    onClick = { onOpenWorldMap() },
                    tag = "btn_carte_monde"
                )

                // COLLECTION
                RpgMenuButton(
                    title = "COLLECTION",
                    subtitle = "Consulter vos reliques & versets débloqués",
                    icon = "📚",
                    goldBorder = false,
                    onClick = { onOpenCollection() },
                    tag = "btn_collection"
                )

                // DÉFIS QUOTIDIENS
                RpgMenuButton(
                    title = "DÉFIS QUOTIDIENS",
                    subtitle = "3 énigmes bibliques du jour (+100 XP)",
                    icon = "📜",
                    goldBorder = false,
                    onClick = { onShowToast("📜 Défi du jour : Quel livre précède l'Exode ? (Prochainement !)") },
                    tag = "btn_defis_quotidiens"
                )

                // BOUTIQUE
                RpgMenuButton(
                    title = "BOUTIQUE",
                    subtitle = "Acquérir des potions de temps & reliques",
                    icon = "🏛️",
                    goldBorder = false,
                    onClick = { onShowToast("🏛️ La boutique du temple ouvrira bientôt !") },
                    tag = "btn_boutique"
                )

                // PARAMÈTRES
                RpgMenuButton(
                    title = "PARAMÈTRES",
                    subtitle = "Sons, langue & réinitialisation",
                    icon = "⚙️",
                    goldBorder = false,
                    onClick = { showSettingsDialog = true },
                    tag = "btn_parametres"
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // 4. Cartes des Livres (CARTE DU MONDE / GENÈSE & EXODE & BOSS)
            Text(
                text = "🗺️ SÉLECTION DES LIVRES",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = GoldPrimary,
                letterSpacing = 1.sp
            )

            // Grid Layout (2x2 Cards)
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Row 1: Genèse & Exode
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // GENÈSE Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CardBackground),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, GoldPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(115.dp)
                            .clickable { onOpenGenese() }
                            .testTag("card_genese")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(10.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Text("📖", fontSize = 24.sp)
                                Surface(
                                    color = GoldPrimary,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "▶️ Jouer",
                                        color = DarkBackground,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = "GENÈSE",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldPrimary
                                )
                                Text(
                                    text = "13 étapes (${(maxUnlockedEtapeGenese - 1).coerceAtLeast(0)}/13)",
                                    fontSize = 11.sp,
                                    color = TextPrimary
                                )
                            }
                        }
                    }

                    // EXODE Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CardBackground),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, GoldPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(115.dp)
                            .clickable { onOpenExode() }
                            .testTag("card_exode")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(10.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Text("📜", fontSize = 24.sp)
                                Surface(
                                    color = AccentBlue,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "✨ Nouveau",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = "EXODE",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldPrimary
                                )
                                Text(
                                    text = "13 étapes (Disponible)",
                                    fontSize = 11.sp,
                                    color = TextPrimary
                                )
                            }
                        }
                    }
                }

                // Row 2: Boss & Collection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // BOSS Card
                    val maxUnlockedEtape = maxOf(maxUnlockedEtapeGenese, maxUnlockedEtapeExode)
                    val isBossUnlocked = maxUnlockedEtape >= 13
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isBossUnlocked) CardBackground else CardBackground.copy(alpha = 0.6f)
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            1.5.dp,
                            if (isBossUnlocked) BossRed else CardBorder
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(115.dp)
                            .clickable {
                                if (isBossUnlocked) {
                                    onOpenBoss()
                                } else {
                                    onShowToast("⚔️ Le Boss est verrouillé. Terminez les 12 étapes d'abord ! (${maxUnlockedEtape - 1}/12)")
                                }
                            }
                            .testTag("card_boss")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(10.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Text("🏆", fontSize = 24.sp)
                                if (isBossUnlocked) {
                                    Text("⚔️", fontSize = 18.sp)
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "Verrouillé",
                                        tint = LockGray,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = "BOSS",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isBossUnlocked) BossRed else TextSecondary
                                )
                                Text(
                                    text = if (isBossUnlocked) "Étape 13 • Combat" else "🔒 ${maxUnlockedEtape - 1}/12 Étapes",
                                    fontSize = 11.sp,
                                    color = if (isBossUnlocked) TextPrimary else LockGray
                                )
                            }
                        }
                    }

                    // RELIQUES & COLLECTION Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CardBackground),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AccentBlue),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(115.dp)
                            .clickable { onOpenCollection() }
                            .testTag("card_collection")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(10.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Text("📚", fontSize = 24.sp)
                                Surface(
                                    color = AccentBlue.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "13 Items",
                                        color = AccentBlue,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = "COLLECTION",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AccentBlue
                                )
                                Text(
                                    text = "Reliques & Objets",
                                    fontSize = 11.sp,
                                    color = TextPrimary
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Footer / Status Banner
            HorizontalDivider(color = CardBorder, thickness = 1.dp)
            Text(
                text = "BibleQuest RPG • Genèse & Exode (3 Niveaux)",
                fontSize = 11.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

    // Dialogs
    if (showProfileDialog) {
        AlertDialog(
            onDismissRequest = { showProfileDialog = false },
            confirmButton = {
                TextButton(onClick = { showProfileDialog = false }) {
                    Text("Fermer", color = GoldPrimary)
                }
            },
            dismissButton = {
                Button(
                    onClick = {
                        showProfileDialog = false
                        onOpenStats()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                ) {
                    Text("📊 Statistiques", color = DarkBackground, fontWeight = FontWeight.Bold)
                }
            },
            title = { Text("👤 Profil de l'Aventurier", color = GoldPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Titre : Disciple de la Parole", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("Niveau : 1 (Disciple)", color = TextPrimary)
                    Text("Livres : Genèse & Exode (Facile, Intermédiaire, Expert)", color = TextSecondary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Poursuivez vos énigmes pour accumuler de l'XP et débloquer de nouveaux titres !", fontSize = 12.sp, color = GoldLight)
                }
            },
            containerColor = CardBackground
        )
    }

    if (showLeaderboardDialog) {
        AlertDialog(
            onDismissRequest = { showLeaderboardDialog = false },
            confirmButton = {
                TextButton(onClick = { showLeaderboardDialog = false }) {
                    Text("Fermer", color = GoldPrimary)
                }
            },
            title = { Text("🏆 Classement des Aventuriers", color = GoldPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("1. Vous (Niv. 1) - 0 XP", color = GoldPrimary, fontWeight = FontWeight.Bold)
                    Text("2. Apollos - 0 XP", color = TextSecondary)
                    Text("3. Timothée - 0 XP", color = TextSecondary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Terminez les 13 étapes de la Genèse et de l'Exode pour gravir les échelons !", fontSize = 11.sp, color = TextSecondary)
                }
            },
            containerColor = CardBackground
        )
    }

    if (showSettingsDialog) {
        AlertDialog(
            onDismissRequest = { showSettingsDialog = false },
            confirmButton = {
                Button(
                    onClick = { showSettingsDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                ) {
                    Text("Valider", color = DarkBackground, fontWeight = FontWeight.Bold)
                }
            },
            title = { Text("⚙️ Paramètres du Jeu", color = GoldPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("🔊 Effets sonores : Activés", color = TextPrimary)
                    Text("🎵 Musique de fond : Activée", color = TextPrimary)
                    Text("🌐 Langue : Français", color = TextPrimary)
                    Text("📖 Version : BibleQuest RPG 1.2", color = TextSecondary, fontSize = 12.sp)
                }
            },
            containerColor = CardBackground
        )
    }
}

@Composable
private fun RpgMenuButton(
    title: String,
    subtitle: String,
    icon: String,
    goldBorder: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (goldBorder) CardBackground else CardBackground.copy(alpha = 0.85f)
        ),
        border = androidx.compose.foundation.BorderStroke(
            if (goldBorder) 1.5.dp else 1.dp,
            if (goldBorder) GoldPrimary else CardBorder
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (goldBorder) GoldPrimary.copy(alpha = 0.2f) else CardBorder),
                contentAlignment = Alignment.Center
            ) {
                Text(icon, fontSize = 20.sp)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (goldBorder) GoldPrimary else TextPrimary,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = if (goldBorder) GoldPrimary else TextSecondary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

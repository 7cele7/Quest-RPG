package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.EtapeData
import com.example.data.QuestionData
import com.example.ui.theme.*

import com.example.data.ProgressManager
import com.example.data.StepSessionData

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StepPlayScreen(
    etape: EtapeData,
    levelKey: String = "facile",
    onBack: () -> Unit,
    onStepCompleted: (Int) -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current

    // Restore saved session if available for this level & etape
    val savedSession = remember(etape.etape, levelKey) {
        val s = ProgressManager.getActiveSession(context, levelKey)
        if (s != null && s.etapeNumber == etape.etape && !s.isStepCompleted) s else null
    }

    var currentQuestionIndex by remember { mutableIntStateOf(savedSession?.currentQuestionIndex ?: 0) }
    var userTextAnswer by remember { mutableStateOf("") }
    var selectedOption by remember { mutableStateOf<String?>(null) }
    var isAnswerSubmitted by remember { mutableStateOf(false) }
    var isCorrectAnswer by remember { mutableStateOf(false) }
    var score by remember { mutableIntStateOf(savedSession?.score ?: 0) }
    var isStepCompleted by remember { mutableStateOf(false) }

    val startTimeMillis = remember { System.currentTimeMillis() }
    var totalTimeSeconds by remember { mutableIntStateOf(0) }

    val isBoss = etape.type == "BOSS" || etape.etape == 13
    val questionsToPlay = remember(etape) { etape.questions }
    val totalQuestions = questionsToPlay.size
    val currentQuestion: QuestionData? = questionsToPlay.getOrNull(currentQuestionIndex)

    var bossTimeLeft by remember(etape) { mutableIntStateOf(90) }
    var bossLives by remember(etape) { mutableIntStateOf(3) }

    val isTimedQuestion = (currentQuestion?.chrono == true) || (currentQuestionIndex >= 10)
    var timeLeft by remember(currentQuestionIndex) { mutableIntStateOf(currentQuestion?.timeLimit ?: 20) }

    // Helper to evaluate keyboard/multiple choice answer
    fun evaluateAnswer(input: String, option: String?, q: QuestionData?): Boolean {
        if (q == null) return false
        return if (q.type == "choix_multiple") {
            option?.trim()?.equals(q.answer.trim(), ignoreCase = true) == true
        } else {
            val cleanInput = input.trim().lowercase()
            if (cleanInput.isEmpty()) return false
            val cleanAnswer = q.answer.trim().lowercase()

            val mainMatch = cleanInput == cleanAnswer ||
                (cleanInput.length >= 3 && cleanAnswer.contains(cleanInput)) ||
                (cleanAnswer.length >= 3 && cleanInput.contains(cleanAnswer))

            val aliasMatch = q.aliases?.any { alias ->
                val cleanAlias = alias.trim().lowercase()
                cleanAlias.isNotEmpty() && (
                    cleanInput == cleanAlias ||
                    cleanInput.contains(cleanAlias) ||
                    cleanAlias.contains(cleanInput)
                )
            } == true

            mainMatch || aliasMatch
        }
    }

    // Helper to auto-save after every question with error notification
    fun autoSave(qIndex: Int, currentScore: Int) {
        val success = ProgressManager.saveActiveSession(
            context,
            StepSessionData(
                levelKey = levelKey,
                etapeNumber = etape.etape,
                currentQuestionIndex = qIndex,
                score = currentScore,
                isStepCompleted = false
            )
        )
        if (!success) {
            Toast.makeText(context, "⚠️ Erreur lors de la sauvegarde automatique.", Toast.LENGTH_SHORT).show()
        }
    }

    // Boss overall timer (90s) and lives check (3 lives)
    LaunchedEffect(isBoss, isStepCompleted) {
        if (isBoss && !isStepCompleted) {
            while (bossTimeLeft > 0 && bossLives > 0 && !isStepCompleted) {
                kotlinx.coroutines.delay(1000L)
                bossTimeLeft--
            }
            if ((bossTimeLeft <= 0 || bossLives <= 0) && !isStepCompleted) {
                isStepCompleted = true
            }
        }
    }

    // Current Boss phase label
    val bossPhaseLabel = if (isBoss) {
        when {
            currentQuestionIndex < (totalQuestions / 3).coerceAtLeast(1) -> "Phase 1 / 3 : Énigmes 🧩"
            currentQuestionIndex < ((totalQuestions * 2) / 3).coerceAtLeast(2) -> "Phase 2 / 3 : Mémoire 🧠"
            else -> "Phase 3 / 3 : Ultimatum ⚔️"
        }
    } else null

    // Notify completion when step is done
    LaunchedEffect(isStepCompleted) {
        if (isStepCompleted) {
            val elapsed = ((System.currentTimeMillis() - startTimeMillis) / 1000).toInt()
            totalTimeSeconds = if (elapsed > 0) elapsed else 1
            ProgressManager.saveEtapeResult(
                context = context,
                levelKey = levelKey,
                etapeNum = etape.etape,
                score = score,
                totalQuestions = totalQuestions,
                timeSeconds = totalTimeSeconds
            )
            ProgressManager.clearActiveSession(context, levelKey)
            onStepCompleted(etape.etape)
        }
    }

    // Countdown Timer for timed questions (questions 11 & 12 or chrono questions)
    LaunchedEffect(currentQuestionIndex, isAnswerSubmitted) {
        if (isTimedQuestion && !isAnswerSubmitted) {
            timeLeft = currentQuestion?.timeLimit ?: 20
            while (timeLeft > 0 && !isAnswerSubmitted) {
                kotlinx.coroutines.delay(1000L)
                timeLeft--
            }
            if (timeLeft == 0 && !isAnswerSubmitted) {
                val correct = evaluateAnswer(userTextAnswer, selectedOption, currentQuestion)
                isCorrectAnswer = correct
                if (!correct && isBoss && bossLives > 0) {
                    bossLives--
                }
                val newScore = if (correct) score + 1 else score
                if (correct) score = newScore
                isAnswerSubmitted = true
                autoSave(currentQuestionIndex, newScore)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (isBoss) "⚔️ BOSS : ${etape.titre}" else "Étape ${etape.etape} : ${etape.titre}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isBoss) BossRed else GoldPrimary
                        )
                        Text(
                            text = if (isBoss) "⏱️ Chrono ${bossTimeLeft}s • ❤️ Vies : ${bossLives.coerceAtLeast(0)} • Question ${currentQuestionIndex + 1}/$totalQuestions"
                            else "${etape.chapitres} • Question ${currentQuestionIndex + 1}/$totalQuestions",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("btn_back_step")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Quitter",
                            tint = if (isBoss) BossRed else GoldPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CardBackground
                )
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            if (isStepCompleted) {
                // Screen shown when step questions are completed
                val percentage = if (totalQuestions > 0) (score * 100) / totalQuestions else 0
                val scoreMessage = when {
                    percentage >= 80 -> "Excellent ! 🌟"
                    percentage >= 50 -> "Bien joué ! 👏"
                    else -> "Continue à t'entraîner ! 💪"
                }
                val formattedTime = if (totalTimeSeconds < 60) {
                    "${totalTimeSeconds}s"
                } else {
                    "${totalTimeSeconds / 60} min ${totalTimeSeconds % 60}s"
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = if (percentage >= 80) "🏆" else if (percentage >= 50) "🎉" else "📖",
                        fontSize = 48.sp
                    )

                    Text(
                        text = if (isBoss) "Résumé du Combat BOSS" else "Résumé de l'Étape ${etape.etape}",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isBoss) BossRed else GoldPrimary,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = scoreMessage,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (percentage >= 50) GoldLight else BossRed,
                        textAlign = TextAlign.Center
                    )

                    // Stats Details Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CardBackground),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "📊 Statistiques de la session",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoldPrimary
                            )

                            HorizontalDivider(color = CardBorder, thickness = 1.dp)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("✅ Réponses correctes :", color = TextSecondary, fontSize = 14.sp)
                                Text("$score / $totalQuestions", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🎯 Taux de réussite :", color = TextSecondary, fontSize = 14.sp)
                                Text("$percentage%", color = if (percentage >= 50) GoldLight else BossRed, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("⏱️ Temps écoulé :", color = TextSecondary, fontSize = 14.sp)
                                Text(formattedTime, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                    }

                    // Reward Unlocked Card (if step is passed)
                    AnimatedVisibility(
                        visible = percentage >= 50,
                        enter = fadeIn(animationSpec = tween(500)) + scaleIn(initialScale = 0.7f, animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy))
                    ) {
                        val rewardInfiniteTransition = rememberInfiniteTransition(label = "rewardPulse")
                        val rewardGlowAlpha by rewardInfiniteTransition.animateFloat(
                            initialValue = 0.5f,
                            targetValue = 1f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(800, easing = LinearEasing),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "rewardGlowAlpha"
                        )

                        Card(
                            colors = CardDefaults.cardColors(containerColor = CardBackground),
                            border = androidx.compose.foundation.BorderStroke(2.dp, GoldPrimary.copy(alpha = rewardGlowAlpha)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("card_reward_unlocked")
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Text("🎉 ", fontSize = 20.sp)
                                    Text("🏆 RÉCOMPENSE DÉBLOQUÉE !", fontSize = 12.sp, color = GoldLight, fontWeight = FontWeight.Bold)
                                    Text(" 🎉", fontSize = 20.sp)
                                }
                                Text(
                                    text = etape.recompense.nom,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldPrimary,
                                    textAlign = TextAlign.Center
                                )
                                Surface(
                                    color = GoldPrimary.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(6.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
                                ) {
                                    Text(
                                        text = "${etape.recompense.type} • ${etape.recompense.rarite}",
                                        color = GoldLight,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                                Text(
                                    text = etape.recompense.description,
                                    fontSize = 12.sp,
                                    color = TextSecondary,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = "📖 ${etape.recompense.verset}",
                                    fontSize = 11.sp,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = onBack,
                        colors = ButtonDefaults.buttonColors(containerColor = if (isBoss) BossRed else GoldPrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_continue_step_summary")
                    ) {
                        Text("Continuer ▶️", color = DarkBackground, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            } else if (currentQuestion != null) {
                // Question Screen
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Boss Phase Banner if Boss
                    if (bossPhaseLabel != null) {
                        Surface(
                            color = BossRed.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, BossRed),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = bossPhaseLabel,
                                color = BossRed,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }
                    }

                    // Question Progress Bar
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Progression : Question ${currentQuestionIndex + 1}/$totalQuestions",
                                fontSize = 12.sp,
                                color = GoldLight,
                                fontWeight = FontWeight.Medium
                            )
                            if (isTimedQuestion) {
                                Text(
                                    text = "⏱️ ${timeLeft}s",
                                    fontSize = 12.sp,
                                    color = if (timeLeft <= 3) BossRed else GoldPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        LinearProgressIndicator(
                            progress = { (currentQuestionIndex + 1).toFloat() / totalQuestions },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp),
                            color = if (isBoss) BossRed else GoldPrimary,
                            trackColor = CardBorder,
                        )
                    }

                    // Question Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CardBackground),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = CardBorder,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = if (currentQuestion.type == "clavier") "⌨️ Réponse Clavier" else "☑️ Choix Multiple",
                                        color = GoldLight,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }

                                if (isTimedQuestion) {
                                    val duration = currentQuestion.timeLimit ?: 10
                                    Surface(
                                        color = BossRed.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(4.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, BossRed)
                                    ) {
                                        Text(
                                            text = "⏱️ Chrono ${duration}s (${timeLeft}s)",
                                            color = BossRed,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = currentQuestion.question,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                        }
                    }

                    // Options or Keyboard Input
                    if (currentQuestion.type == "choix_multiple" && currentQuestion.options != null) {
                        val shuffledOptions = remember(currentQuestionIndex, currentQuestion) {
                            currentQuestion.options.shuffled()
                        }
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            shuffledOptions.forEachIndexed { index, option ->
                                val optionPrefix = when (index) {
                                    0 -> "A"
                                    1 -> "B"
                                    2 -> "C"
                                    3 -> "D"
                                    else -> "${index + 1}"
                                }
                                val isSelected = selectedOption == option
                                val optionColor = when {
                                    !isAnswerSubmitted && isSelected -> GoldPrimary
                                    isAnswerSubmitted && option.trim().equals(currentQuestion.answer.trim(), ignoreCase = true) -> CommonGreen
                                    isAnswerSubmitted && isSelected && !option.trim().equals(currentQuestion.answer.trim(), ignoreCase = true) -> BossRed
                                    else -> CardBorder
                                }

                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) CardBorder else CardBackground
                                    ),
                                    border = androidx.compose.foundation.BorderStroke(1.5.dp, optionColor),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable(enabled = !isAnswerSubmitted) {
                                            selectedOption = option
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(
                                            color = if (isSelected) GoldPrimary else CardBorder,
                                            shape = RoundedCornerShape(4.dp),
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = optionPrefix,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isSelected) DarkBackground else TextPrimary,
                                                    fontSize = 12.sp
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text(
                                            text = option,
                                            fontSize = 14.sp,
                                            color = TextPrimary,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        // Keyboard input question
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = userTextAnswer,
                                onValueChange = { if (!isAnswerSubmitted) userTextAnswer = it },
                                label = { Text("Votre réponse...") },
                                enabled = !isAnswerSubmitted,
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoldPrimary,
                                    unfocusedBorderColor = CardBorder,
                                    focusedLabelColor = GoldPrimary
                                )
                            )
                        }
                    }

                    // Feedback box if submitted
                    if (isAnswerSubmitted) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isCorrectAnswer) CommonGreen.copy(alpha = 0.2f) else BossRed.copy(alpha = 0.2f)
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isCorrectAnswer) CommonGreen else BossRed),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = if (isCorrectAnswer) "✅ Bonne réponse !" else "❌ Réponse incorrecte",
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCorrectAnswer) CommonGreen else BossRed
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Réponse attendue : ${currentQuestion.answer}",
                                    fontSize = 12.sp,
                                    color = TextPrimary
                                )
                                if (!currentQuestion.reference.isNull_or_blank()) {
                                    Text(
                                        text = "📖 Référence : ${currentQuestion.reference}",
                                        fontSize = 11.sp,
                                        color = GoldPrimary
                                    )
                                }
                            }
                        }
                    }

                    // Action Button (Valider / Suivant)
                    Button(
                        onClick = {
                            if (!isAnswerSubmitted) {
                                // Submit answer
                                val correct = evaluateAnswer(userTextAnswer, selectedOption, currentQuestion)

                                isCorrectAnswer = correct
                                if (!correct && isBoss && bossLives > 0) {
                                    bossLives--
                                }
                                val newScore = if (correct) score + 1 else score
                                score = newScore
                                isAnswerSubmitted = true
                                autoSave(currentQuestionIndex, newScore)
                            } else {
                                // Next question
                                if (currentQuestionIndex + 1 < totalQuestions) {
                                    val nextIndex = currentQuestionIndex + 1
                                    currentQuestionIndex = nextIndex
                                    selectedOption = null
                                    userTextAnswer = ""
                                    isAnswerSubmitted = false
                                    autoSave(nextIndex, score)
                                } else {
                                    isStepCompleted = true
                                }
                            }
                        },
                        enabled = if (!isAnswerSubmitted) {
                            if (currentQuestion.type == "choix_multiple") selectedOption != null else userTextAnswer.isNotBlank()
                        } else true,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isBoss) BossRed else GoldPrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (!isAnswerSubmitted) "Valider la réponse" else if (currentQuestionIndex + 1 < totalQuestions) "Question suivante ▶️" else "Voir le résultat 🎉",
                            color = DarkBackground,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else {
                // Fallback Error View if question is missing or corrupted
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardBackground),
                    border = BorderStroke(1.5.dp, BossRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .testTag("card_question_error")
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text("⚠️", fontSize = 48.sp)
                        Text(
                            text = "Impossible d'afficher la question",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = BossRed,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Une erreur est survenue lors de l'affichage de la question ${currentQuestionIndex + 1}.",
                            fontSize = 13.sp,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = {
                                    if (currentQuestionIndex + 1 < totalQuestions) {
                                        currentQuestionIndex++
                                        selectedOption = null
                                        userTextAnswer = ""
                                        isAnswerSubmitted = false
                                    } else {
                                        isStepCompleted = true
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                            ) {
                                Text("Réessayer / Suivant ⏩", color = DarkBackground, fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(
                                onClick = onBack,
                                border = BorderStroke(1.dp, CardBorder)
                            ) {
                                Text("Retour", color = TextPrimary)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun String?.isNull_or_blank(): Boolean = this == null || this.trim().isEmpty()

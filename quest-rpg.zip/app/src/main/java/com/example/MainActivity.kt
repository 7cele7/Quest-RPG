package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.*
import com.example.data.EtapeData
import com.example.data.JsonLoader
import com.example.data.LivreData
import com.example.data.ProgressManager
import com.example.ui.BookScreen
import com.example.ui.CollectionScreen
import com.example.ui.MainHubScreen
import com.example.ui.SplashScreen
import com.example.ui.StatsScreen
import com.example.ui.StepPlayScreen
import com.example.ui.WorldMapScreen
import com.example.ui.theme.BibleQuestTheme

enum class AppScreen {
    SPLASH,
    HUB,
    WORLD_MAP,
    BOOK_GENESE,
    COLLECTION,
    STATS,
    STEP_PLAY
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            BibleQuestTheme {
                var currentScreen by remember { mutableStateOf(AppScreen.SPLASH) }
                var selectedBookKey by remember { mutableStateOf("genese") }
                var selectedLevelKey by remember { mutableStateOf("facile") }
                var selectedEtapeToPlay by remember { mutableStateOf<EtapeData?>(null) }

                val currentProgressKey = remember(selectedBookKey, selectedLevelKey) {
                    if (selectedBookKey == "genese" && selectedLevelKey == "facile") "facile"
                    else "${selectedBookKey}_${selectedLevelKey}"
                }

                val currentLivreData = remember(selectedBookKey, selectedLevelKey) {
                    JsonLoader.loadLivreLevel(this@MainActivity, "${selectedBookKey}_$selectedLevelKey.json")
                }
                val currentLoadError = JsonLoader.lastErrorMessage

                var maxUnlockedEtape by remember(currentProgressKey) {
                    mutableIntStateOf(ProgressManager.getMaxUnlockedEtape(this@MainActivity, currentProgressKey))
                }

                AnimatedContent(
                    targetState = currentScreen,
                    transitionSpec = {
                        fadeIn(animationSpec = tween(280, easing = FastOutSlowInEasing)) +
                            slideInHorizontally(
                                initialOffsetX = { if (targetState.ordinal > initialState.ordinal) it / 2 else -it / 2 },
                                animationSpec = tween(280, easing = FastOutSlowInEasing)
                            ) togetherWith
                            fadeOut(animationSpec = tween(200)) +
                            slideOutHorizontally(
                                targetOffsetX = { if (targetState.ordinal > initialState.ordinal) -it / 2 else it / 2 },
                                animationSpec = tween(200)
                            )
                    },
                    label = "ScreenTransition"
                ) { screen ->
                    when (screen) {
                        AppScreen.SPLASH -> {
                            SplashScreen(
                                onTimeout = { currentScreen = AppScreen.HUB }
                            )
                        }

                        AppScreen.HUB -> {
                            val geneseMaxUnlocked = remember { ProgressManager.getMaxUnlockedEtape(this@MainActivity, "facile") }
                            val exodeMaxUnlocked = remember { ProgressManager.getMaxUnlockedEtape(this@MainActivity, "exode_facile") }
                            MainHubScreen(
                                maxUnlockedEtapeGenese = geneseMaxUnlocked,
                                maxUnlockedEtapeExode = exodeMaxUnlocked,
                                onOpenGenese = {
                                    selectedBookKey = "genese"
                                    currentScreen = AppScreen.BOOK_GENESE
                                },
                                onOpenExode = {
                                    selectedBookKey = "exode"
                                    currentScreen = AppScreen.BOOK_GENESE
                                },
                                onOpenBoss = {
                                    val bossEtape = currentLivreData?.etapes?.find { it.etape == 13 || it.type == "BOSS" }
                                        ?: currentLivreData?.etapes?.lastOrNull()
                                    val currentMaxUnlocked = if (selectedBookKey == "genese") geneseMaxUnlocked else exodeMaxUnlocked
                                    if (bossEtape != null) {
                                        if (currentMaxUnlocked >= 13) {
                                            selectedEtapeToPlay = bossEtape
                                            currentScreen = AppScreen.STEP_PLAY
                                        } else {
                                            Toast.makeText(this@MainActivity, "⚔️ Le Boss est verrouillé. Terminez les 12 étapes d'abord !", Toast.LENGTH_SHORT).show()
                                        }
                                    } else {
                                        Toast.makeText(this@MainActivity, "Boss indisponible", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onOpenCollection = { currentScreen = AppScreen.COLLECTION },
                                onOpenStats = { currentScreen = AppScreen.STATS },
                                onShowToast = { msg -> Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show() },
                                onOpenWorldMap = { currentScreen = AppScreen.WORLD_MAP }
                            )
                        }

                        AppScreen.WORLD_MAP -> {
                            val geneseMaxUnlocked = remember { ProgressManager.getMaxUnlockedEtape(this@MainActivity, "facile") }
                            val exodeMaxUnlocked = remember { ProgressManager.getMaxUnlockedEtape(this@MainActivity, "exode_facile") }
                            WorldMapScreen(
                                geneseUnlockedEtape = geneseMaxUnlocked,
                                exodeUnlockedEtape = exodeMaxUnlocked,
                                onSelectGenese = {
                                    selectedBookKey = "genese"
                                    currentScreen = AppScreen.BOOK_GENESE
                                },
                                onSelectExode = {
                                    selectedBookKey = "exode"
                                    currentScreen = AppScreen.BOOK_GENESE
                                },
                                onBack = { currentScreen = AppScreen.HUB }
                            )
                        }

                        AppScreen.STATS -> {
                            StatsScreen(
                                onBack = { currentScreen = AppScreen.HUB }
                            )
                        }

                        AppScreen.BOOK_GENESE -> {
                            BookScreen(
                                livreData = currentLivreData,
                                errorMessage = currentLoadError,
                                maxUnlockedEtape = maxUnlockedEtape,
                                selectedLevelKey = selectedLevelKey,
                                onSelectLevel = { newLevel ->
                                    selectedLevelKey = newLevel
                                },
                                onResetLevel = {
                                    ProgressManager.resetLevelProgress(this@MainActivity, currentProgressKey)
                                    maxUnlockedEtape = ProgressManager.getMaxUnlockedEtape(this@MainActivity, currentProgressKey)
                                    Toast.makeText(this@MainActivity, "Progression du niveau réinitialisée !", Toast.LENGTH_SHORT).show()
                                },
                                onBack = { currentScreen = AppScreen.HUB },
                                onSelectEtapeToPlay = { etape ->
                                    selectedEtapeToPlay = etape
                                    currentScreen = AppScreen.STEP_PLAY
                                }
                            )
                        }

                        AppScreen.COLLECTION -> {
                            CollectionScreen(
                                livreData = currentLivreData,
                                onBack = { currentScreen = AppScreen.HUB }
                            )
                        }

                        AppScreen.STEP_PLAY -> {
                            selectedEtapeToPlay?.let { etape ->
                                StepPlayScreen(
                                    etape = etape,
                                    levelKey = currentProgressKey,
                                    onBack = { currentScreen = AppScreen.BOOK_GENESE },
                                    onStepCompleted = { completedEtapeNum ->
                                        ProgressManager.unlockNextEtape(this@MainActivity, completedEtapeNum, currentProgressKey)
                                        maxUnlockedEtape = ProgressManager.getMaxUnlockedEtape(this@MainActivity, currentProgressKey)
                                    }
                                )
                            } ?: run {
                                currentScreen = AppScreen.BOOK_GENESE
                            }
                        }
                    }
                }
            }
        }
    }
}

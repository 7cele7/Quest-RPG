package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val SplashGoldPrimary = Color(0xFFC9A84C)
private val SplashDarkBackground = Color(0xFF0F0D0A)
private val SplashBrownDark = Color(0xFF2C1810)
private val SplashTextPrimary = Color(0xFFF5E6D3)
private val SplashGoldLight = Color(0xFFF4D068)

@Composable
fun SplashScreen(
    onTimeout: () -> Unit
) {
    var startAnimation by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        startAnimation = true
        delay(2500L)
        onTimeout()
    }

    val alphaAnim by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "SplashAlpha"
    )

    val scaleAnim by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0.85f,
        animationSpec = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
        label = "SplashScale"
    )

    // Glowing pulse animation for the title halo & icon
    val infiniteTransition = rememberInfiniteTransition(label = "SplashPulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseScale"
    )

    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "GlowAlpha"
    )

    val backgroundBrush = Brush.verticalGradient(
        colors = listOf(
            SplashDarkBackground,
            SplashBrownDark,
            SplashDarkBackground
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundBrush)
            .testTag("splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        // Luminous pulsing aura behind central title & icon
        Box(
            modifier = Modifier
                .size(340.dp)
                .scale(pulseScale)
                .alpha(glowAlpha * alphaAnim)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            SplashGoldPrimary,
                            SplashGoldLight.copy(alpha = 0.5f),
                            Color.Transparent
                        )
                    ),
                    shape = CircleShape
                )
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .alpha(alphaAnim)
                .scale(scaleAnim)
                .padding(32.dp)
        ) {
            // Cross Icon Badge
            Box(
                modifier = Modifier
                    .size(88.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(SplashBrownDark, SplashDarkBackground)
                        )
                    )
                    .border(2.dp, SplashGoldPrimary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "✝",
                    fontSize = 42.sp,
                    color = SplashGoldPrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Main Title "BibleQuest"
            Text(
                text = "BibleQuest",
                fontSize = 46.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Serif,
                color = SplashGoldPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier.scale(pulseScale),
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Subtitle "RPG"
            Text(
                text = "R P G",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = SplashGoldLight,
                textAlign = TextAlign.Center,
                letterSpacing = 6.sp
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Gold divider line
            Box(
                modifier = Modifier
                    .width(160.dp)
                    .height(2.dp)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                Color.Transparent,
                                SplashGoldPrimary,
                                Color.Transparent
                            )
                        )
                    )
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Secondary Subtitle
            Text(
                text = "AVENTURE  ·  ÉNIGMES  ·  BOSS  ·  RELIQUES",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = SplashTextPrimary,
                textAlign = TextAlign.Center,
                letterSpacing = 1.2.sp
            )

            Spacer(modifier = Modifier.height(48.dp))

            // Subtle loading indicator badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(SplashBrownDark.copy(alpha = 0.6f))
                    .border(1.dp, SplashGoldPrimary.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "📜 Chargement de la quête...",
                    fontSize = 12.sp,
                    color = SplashTextPrimary.copy(alpha = 0.85f),
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GlobalBookStats
import com.example.data.LevelStats
import com.example.data.ProgressManager
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen(
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val globalStats = remember { ProgressManager.getGlobalBookStats(context) }

    Scaffold(
        containerColor = DarkBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "📊 Statistiques & Progression",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldPrimary
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("btn_back_stats")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Retour",
                            tint = GoldPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CardBackground
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Vue d'ensemble du Livre (Genèse)
            BookGlobalOverviewCard(globalStats)

            HorizontalDivider(color = CardBorder, thickness = 1.dp)

            // 2. Title Section - Progression par niveau
            Text(
                text = "🎮 PROGRESSION PAR NIVEAU",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = GoldPrimary,
                letterSpacing = 1.sp
            )

            // 3. Render cards for each level (Facile, Intermédiaire, Expert)
            globalStats.levelStatsList.forEach { levelStat ->
                LevelStatCard(levelStat)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Footer info
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBackground.copy(alpha = 0.5f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("💡", fontSize = 20.sp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Répondez correctement aux questions pour faire grimper votre taux de réussite et votre temps de maîtrise !",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun BookGlobalOverviewCard(stats: GlobalBookStats) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(GoldPrimary, CardBorder))),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_global_book_stats")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("📖", fontSize = 26.sp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "LIVRE : ${stats.bookName.uppercase()}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary
                        )
                        Text(
                            text = "Progression globale 3 Niveaux",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                Surface(
                    color = GoldPrimary.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
                ) {
                    Text(
                        text = "${(stats.completedEtapes * 100) / stats.totalEtapes}%",
                        color = GoldPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Global Steps Bar
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Étapes débloquées & terminées",
                        fontSize = 12.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = "${stats.completedEtapes} / ${stats.totalEtapes} étapes",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldLight
                    )
                }

                LinearProgressIndicator(
                    progress = { if (stats.totalEtapes > 0) stats.completedEtapes.toFloat() / stats.totalEtapes else 0f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp)),
                    color = GoldPrimary,
                    trackColor = CardBorder
                )
            }

            HorizontalDivider(color = CardBorder, thickness = 1.dp)

            // 3 Stat Badges in a Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Taux de Réussite
                StatSummaryBadge(
                    modifier = Modifier.weight(1f),
                    icon = "🎯",
                    label = "Réussite",
                    value = "${stats.successRatePercentage}%",
                    valueColor = if (stats.successRatePercentage >= 50) GoldLight else BossRed
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Bonnes Réponses
                StatSummaryBadge(
                    modifier = Modifier.weight(1f),
                    icon = "✅",
                    label = "Bonnes Rép.",
                    value = "${stats.totalCorrectAnswers}",
                    valueColor = TextPrimary
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Temps Total
                StatSummaryBadge(
                    modifier = Modifier.weight(1f),
                    icon = "⏱️",
                    label = "Temps Total",
                    value = stats.formattedTime,
                    valueColor = AccentBlue
                )
            }
        }
    }
}

@Composable
private fun StatSummaryBadge(
    modifier: Modifier = Modifier,
    icon: String,
    label: String,
    value: String,
    valueColor: Color
) {
    Surface(
        modifier = modifier,
        color = DarkBackground.copy(alpha = 0.6f),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(icon, fontSize = 16.sp)
            Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = valueColor, textAlign = TextAlign.Center)
            Text(label, fontSize = 10.sp, color = TextSecondary, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun LevelStatCard(stat: LevelStats) {
    val levelName = when (stat.levelKey) {
        "facile" -> "Facile 🟢"
        "intermediaire" -> "Intermédiaire 🟡"
        "expert" -> "Expert 🔴"
        else -> stat.levelKey.replaceFirstChar { it.uppercase() }
    }

    val themeColor = when (stat.levelKey) {
        "facile" -> CommonGreen
        "intermediaire" -> GoldPrimary
        "expert" -> BossRed
        else -> GoldPrimary
    }

    val progressFraction = if (stat.totalEtapes > 0) stat.completedEtapes.toFloat() / stat.totalEtapes else 0f
    val progressPct = (progressFraction * 100).toInt()

    Card(
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = androidx.compose.foundation.BorderStroke(1.dp, themeColor.copy(alpha = 0.6f)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_level_stat_${stat.levelKey}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = levelName,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = themeColor
                )

                Surface(
                    color = themeColor.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, themeColor)
                ) {
                    Text(
                        text = "${stat.completedEtapes} / ${stat.totalEtapes} Étapes",
                        color = themeColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            // Progress Bar
            LinearProgressIndicator(
                progress = { progressFraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = themeColor,
                trackColor = CardBorder
            )

            // Stats grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Correct Answers & Questions
                Column(modifier = Modifier.weight(1f)) {
                    Text("✅ Bonnes réponses :", fontSize = 11.sp, color = TextSecondary)
                    Text(
                        text = "${stat.totalCorrectAnswers} / ${stat.totalQuestionsAttempted} Qs",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                // Success rate
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🎯 Réussite :", fontSize = 11.sp, color = TextSecondary)
                    Text(
                        text = "${stat.successRatePercentage}%",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (stat.successRatePercentage >= 50) GoldLight else TextSecondary
                    )
                }

                // Time spent
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text("⏱️ Temps passé :", fontSize = 11.sp, color = TextSecondary)
                    Text(
                        text = stat.formattedTime,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
            }
        }
    }
}

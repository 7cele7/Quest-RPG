package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GoldPrimary = Color(0xFFD4AF37)
val GoldLight = Color(0xFFFFDF00)
val DarkBackground = Color(0xFF14121E)
val CardBackground = Color(0xFF221E33)
val CardBorder = Color(0xFF3D345B)
val TextPrimary = Color(0xFFF7F5EC)
val TextSecondary = Color(0xFFB0A8B9)
val AccentBlue = Color(0xFF4E82EA)
val BossRed = Color(0xFFE53935)
val RarePurple = Color(0xFF9C27B0)
val LegendaryGold = Color(0xFFFFB300)
val CommonGreen = Color(0xFF4CAF50)
val LockGray = Color(0xFF555062)
